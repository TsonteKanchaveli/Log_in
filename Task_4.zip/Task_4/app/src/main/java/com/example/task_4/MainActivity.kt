package com.example.task_4

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.TextView

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val clickButton = findViewById<TextView>(R.id.Continue_Button)

        clickButton.setOnClickListener {
            startActivity(Intent(this,MainActivity2::class.java))
        }
    }
}