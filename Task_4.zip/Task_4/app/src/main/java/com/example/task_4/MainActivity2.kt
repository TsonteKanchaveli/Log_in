package com.example.task_4

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast

class MainActivity2 : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main2)

        val cont = findViewById<TextView>(R.id.TextView_Button)
        val email = findViewById<EditText>(R.id.Email).text
        val pass = findViewById<EditText>(R.id.password).text

        cont.setOnClickListener{
            if (email.isEmpty()||pass.isEmpty()){
                Toast.makeText(this, "ERROR",Toast.LENGTH_LONG )
            }else{
                startActivity(Intent(this, MainActivity3::class.java))
            }
        }
    }
}